#!/bin/env/python3

stnce = input("Enter a sentence: ").split(' ')
l = stnce[0]
for w in stnce:
	if len(w) >= len(l):
		l = w
print(f"Longest Word: {l}")
print(f"Length: {len(l)}")
