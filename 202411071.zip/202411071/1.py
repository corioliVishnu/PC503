#!/bin/env/python3

List = list(map(int, input("Enter numbers (space-seperated): ").split(' ')))
print(f"Sum: {sum(List)}")
print(f"Average: {(sum(List)/len(List)):.2f}")
print(f"Max: {max(List)}")
print(f"Min: {min(List)}")
