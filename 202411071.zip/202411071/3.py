#!/bin/env/python3

res = []
N = int(input())
for _ in range(N):
	n = int(input())
	arr = list(map(int, input().split(' ')))
	res.append(max(arr))
for i in res:
	print(i)
