#!/bin/env/python3

res = 1
N = int(input())
for i in range(N):
	ele = int(input())
	res *= ele
print(res)
